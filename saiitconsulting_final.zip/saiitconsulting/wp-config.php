<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'saiitconsulting' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );
    
define('FS_METHOD','direct');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '.4Fs/KZYf7ImcJRYpl@$Yer;=P5NLnQkn_d~WuXFy>q6i8zZfvAF/6 g+s3xi=@+' );
define( 'SECURE_AUTH_KEY',  's2NWpcw4!sGv#:xM$D$Q$28Sho.g]jfCKouat$CZ]ZaS~d:Tc=GN?S=v=b|A4/KN' );
define( 'LOGGED_IN_KEY',    '`W]TTgI:odd{T?;U_OBeb[+o0.phsQq%f|@^7A;XB!Oy(5/{iielrLTDw,F{$Yvk' );
define( 'NONCE_KEY',        'K+3rF{ ]1TIGq|+O@;.]USMHcFU)&`w(%[.~*w)`06~>sVz#KJk:P.RZOoi[|]UL' );
define( 'AUTH_SALT',        'khq$A,Zc.c9q4mUR7{M1g8Hu(RmrIl5*sp1*W7ha]SDR[H-1;a3B:lo`)V%M)HoO' );
define( 'SECURE_AUTH_SALT', 'NaBcA+Ra/k7_,;qr[1G9QM+B6Z=KzyqpIk2%&SEMmi[wF?{#q(&IF]h&RUJH[@LJ' );
define( 'LOGGED_IN_SALT',   '|ePd6/#98CN,0%cVSTf9se)R56s5F]y,X%|_l0kj(5XAMGVo5kcQQ0OZP-q)lpm8' );
define( 'NONCE_SALT',       'erbdffM}YwP`/SnF{2UXZ.Kdir$P?};{vg+~$BU[!]lVOixZ-b/}T>@w4VMyGoS6' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
